import React from 'react';
import { CourseHero } from './components/CourseHero';
import { VideoSection } from './components/VideoSection';
import { CourseDescription } from './components/CourseDescription';
import { CTAButton } from './components/CTAButton';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      {/* Hero Section - Nome do Curso */}
      <CourseHero />
      
      {/* Main Content */}
      <main className="container mx-auto px-4 py-12 max-w-5xl">
        {/* Video Section */}
        <VideoSection />
        
        {/* Course Description */}
        <CourseDescription />
        
        {/* Call to Action */}
        <CTAButton />
      </main>
      
      {/* Footer */}
      <Footer />
    </div>
  );
}
