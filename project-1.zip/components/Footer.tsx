import React from 'react';
import { Mail, Phone, Instagram, Facebook, Youtube, Linkedin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-slate-900 text-white py-12 px-4">
      <div className="container mx-auto max-w-5xl">
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          {/* Sobre */}
          <div>
            <h3 className="text-xl font-bold mb-4">Cakto & Kirvano</h3>
            <p className="text-slate-400">
              Educação de qualidade para transformar carreiras e realizar sonhos.
            </p>
          </div>
          
          {/* Contato */}
          <div>
            <h3 className="text-xl font-bold mb-4">Contato</h3>
            <div className="space-y-3">
              <a href="mailto:heroderick11@gmail.com" className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors">
                <Mail className="w-5 h-5" />
                heroderick11@gmail.com
              </a>
              <a href="tel:+5511942421325" className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors">
                <Phone className="w-5 h-5" />
                (11) 94242-1325
              </a>
            </div>
          </div>
        </div>
        
        {/* Copyright */}
        <div className="border-t border-slate-800 pt-8 text-center text-slate-400">
          <p>&copy; {new Date().getFullYear()} Cakto & Kirvano. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}