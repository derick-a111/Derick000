import React from 'react';
import { CheckCircle } from 'lucide-react';

export function CourseDescription() {
  return (
    <section className="mb-12">
      <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12">
        <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-6 text-center">
          Sobre o Curso
        </h2>
        
        <div className="prose prose-lg max-w-none text-slate-700 mb-8">
          <p className="text-lg leading-relaxed mb-4">
            Quer vender seu produto ou serviço rapidamente? Neste curso exclusivo, você vai aprender 
            estratégias práticas e comprovadas para fazer sua primeira venda em apenas 24 horas!
          </p>
          <p className="text-lg leading-relaxed">
            Sem enrolação, com passos claros e diretos, você vai descobrir como atrair clientes, criar 
            ofertas irresistíveis e fechar negócios de forma rápida e eficaz. Não perca tempo, comece 
            agora e transforme seu sonho em lucro imediato!
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-4 mt-8">
          <div className="flex items-start gap-3">
            <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-semibold text-slate-800 mb-1">Resultados em 24h</h3>
              <p className="text-slate-600">Estratégias práticas para sua primeira venda</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-semibold text-slate-800 mb-1">Método Comprovado</h3>
              <p className="text-slate-600">Técnicas testadas e validadas</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-semibold text-slate-800 mb-1">Passo a Passo Claro</h3>
              <p className="text-slate-600">Sem enrolação, direto ao ponto</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-semibold text-slate-800 mb-1">Ofertas Irresistíveis</h3>
              <p className="text-slate-600">Aprenda a criar propostas que vendem</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}