import React from 'react';
import { ArrowRight, ShoppingCart } from 'lucide-react';

export function CTAButton() {
  return (
    <section className="mb-12">
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 rounded-2xl shadow-2xl p-12 text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
          Pronto para Começar?
        </h2>
        <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
          Não perca esta oportunidade de transformar sua carreira. Inscreva-se agora!
        </p>
        
        <a
          href="https://pay.cakto.com.br/CG6miE9?affiliate=ApDGTr7H"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-3 bg-white text-blue-700 px-10 py-5 rounded-full text-xl font-bold shadow-xl hover:shadow-2xl hover:scale-105 transition-all duration-300 hover:bg-blue-50"
        >
          <ShoppingCart className="w-6 h-6" />
          Compre Agora
          <ArrowRight className="w-6 h-6" />
        </a>
        
        <p className="text-sm text-blue-100 mt-6">
          Garanta sua vaga com condições especiais
        </p>
      </div>
    </section>
  );
}