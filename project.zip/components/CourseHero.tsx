import React from 'react';

export function CourseHero() {
  return (
    <header className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 text-white py-16 px-4">
      <div className="container mx-auto max-w-5xl text-center">
        <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold mb-4 leading-tight">
          Curso Completo de Marketing Digital
        </h1>
        <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto">
          Transforme sua carreira com conhecimento de qualidade
        </p>
      </div>
    </header>
  );
}