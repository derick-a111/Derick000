import React from 'react';
import { Play } from 'lucide-react';

export function VideoSection() {
  return (
    <section className="mb-12">
      <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
        <div className="relative w-full" style={{ paddingBottom: '56.25%' }}>
          <iframe
            className="absolute top-0 left-0 w-full h-full"
            src="https://www.youtube.com/embed/IrlMGxBNhkQ"
            title="Vídeo de Apresentação do Curso"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
      </div>
    </section>
  );
}